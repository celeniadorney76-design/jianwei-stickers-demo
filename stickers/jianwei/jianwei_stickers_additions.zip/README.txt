见微表情新增包：6张单图+20张从5列4行合集拆分的图片。
将 stickers/ 文件夹上传到 GitHub 仓库根目录，并把 new_stickers.json 的数组条目合并到现有 stickers.json 的 stickers 数组。
之后更新 sitemap.xml 图片索引及静态 HTML 图片列表。
注意：本包尚未发布到 GitHub Pages。
